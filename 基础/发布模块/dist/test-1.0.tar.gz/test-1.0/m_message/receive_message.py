def receive():
    return "这是来自100的短信"